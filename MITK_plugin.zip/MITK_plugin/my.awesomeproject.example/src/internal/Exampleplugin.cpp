/*===================================================================

The Medical Imaging Interaction Toolkit (MITK)

Copyright (c) German Cancer Research Center,
Division of Medical and Biological Informatics.
All rights reserved.

This software is distributed WITHOUT ANY WARRANTY; without
even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE.

See LICENSE.txt or http://www.mitk.org for details.

===================================================================*/


// Blueberry
#include <berryISelectionService.h>
#include <berryIWorkbenchWindow.h>

// Qmitk
#include "Exampleplugin.h"

// Qt
#include <QMessageBox>

// mitk image
#include <mitkImage.h>
#include <mitkimageCast.h>
#include <mitkExtractImageFilter.h>
#include <mitkITKImageImport.h>
typedef itk::Image <itk::RGBPixel< unsigned char >, 2 > ImageType_2D;
typedef itk::Image < unsigned char, 2 > ImageType_2D_gray;
typedef itk::Image < unsigned char, 3 > ImageType_3D_gray;
typedef itk::Image<float, 3>  ImageType;
#include "itkImage.h"
#include "itkImageFileWriter.h"
#include "itkRescaleIntensityImageFilter.h"
#include "itkShrinkImageFilter.h"
#include "itkImageDuplicator.h"
#include "itkStatisticsImageFilter.h"
#include <mitkSurface.h>
#include "itkImageFileReader.h"
#include "itkRGBToLuminanceImageFilter.h"
#include "itkTileImageFilter.h"
#include "itkInPlaceImageFilter.h"
#include "itkSmartPointer.h"
#include "itkPasteImageFilter.hxx"
#include "itkExtractImageFilter.h"
#include "itkCropImageFilter.h"
//vtk
#include <vtkImageResample.h>
#include <vtkVersion.h>
#include <vtkSmartPointer.h>
#include <vtkPointData.h>
#include <vtkSphereSource.h>
#include <vtkArrowSource.h>
#include <vtkPolyData.h>
#include <vtkPoints.h>
#include <vtkGlyph3D.h>
#include <vtkCellArray.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkXMLPolyDataWriter.h>
#include <vtkFloatArray.h>

void DeepCopy(ImageType::Pointer input, ImageType::Pointer output);
void mergeLabel(ImageType::Pointer label, float from, float to);
void sortLabel(ImageType::Pointer label, int labelNum);

using namespace std;
const std::string Exampleplugin::VIEW_ID = "org.mitk.views.exampleplugin";

//global varables
ImageType::Pointer LD = ImageType::New();
int labelnum0;
int ** position_0;
float** vel;

void Exampleplugin::SetFocus()
{
  m_Controls.buttonPerformImageProcessing->setFocus();
}

void Exampleplugin::CreateQtPartControl(QWidget *parent)
{
  // create GUI widgets from the Qt Designer's .ui file
  m_Controls.setupUi(parent);
  connect(m_Controls.buttonPerformImageProcessing, SIGNAL(clicked()), this, SLOT(DoImageProcessing()));
  connect(m_Controls.buttonCrop, SIGNAL(clicked()), this, SLOT(DoImageTest()));
  connect(m_Controls.moveSpin, SIGNAL(valueChanged(int)), this, SLOT(movechangeSpin()));
  connect(m_Controls.moveSlider, SIGNAL(valueChanged(int)), this, SLOT(movechangeSlider()));
  connect(m_Controls.buttonLabel, SIGNAL(clicked()), this, SLOT(DoLabeling()));
  connect(m_Controls.buttonLabel2, SIGNAL(clicked()), this, SLOT(DoLabeling2()));
  connect(m_Controls.buttonTracking, SIGNAL(clicked()), this, SLOT(DoTracking()));
  connect(m_Controls.buttonTracking2, SIGNAL(clicked()), this, SLOT(DoTracking2()));
  connect(m_Controls.buttonTesting, SIGNAL(clicked()), this, SLOT(DoTest()));
}

void Exampleplugin::OnSelectionChanged(berry::IWorkbenchPart::Pointer /*source*/,
                                                const QList<mitk::DataNode::Pointer> &nodes)
{
  // iterate all selected objects, adjust warning visibility
  foreach (mitk::DataNode::Pointer node, nodes)
  {
    if (node.IsNotNull() && dynamic_cast<mitk::Image *>(node->GetData()))
    {
      m_Controls.labelWarning->setVisible(false);
      m_Controls.buttonPerformImageProcessing->setEnabled(true);
	  m_Controls.moveSpin->setEnabled(true);
	  //m_Controls.moveSpin->setMaximum();
	  m_Controls.moveSlider->setEnabled(true);
      return;
    }
  }

  m_Controls.labelWarning->setVisible(true);
  m_Controls.buttonPerformImageProcessing->setEnabled(false);
  m_Controls.moveSpin->setEnabled(false);
  m_Controls.moveSlider->setEnabled(false);
}

// Image Automatic Cropper
// 1. Load 2 images (Medical Image, Segmentation Label)
// 2. Press the crop button
// 3. Crop image is generated.
// 4. Save it.
void Exampleplugin::DoImageProcessing()
{
	QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
	if (nodes.empty())
		return;

	mitk::DataNode *node = nodes.at(1);
	mitk::DataNode *node_target = nodes.at(0);

	if (!node | !node_target)
	{
		// Nothing selected. Inform the user and return
		QMessageBox::information(NULL, "Template", "Please load and select an image before starting image processing.");
		return;
	}

	// here we have a valid mitk::DataNode

	// a node itself is not very useful, we need its data item (the image)
	mitk::BaseData *data = node->GetData();
	mitk::BaseData *target = node_target->GetData();
	if (data && target)
	{
		// test if this data item is an image or not (could also be a surface or something totally different)
		mitk::Image *image = dynamic_cast<mitk::Image *>(data);
		mitk::Image *image_target = dynamic_cast<mitk::Image *>(target);
		mitk::Vector3D image_spacing = image->GetGeometry()->GetSpacing();
		mitk::Vector3D target_spacing = image_target->GetGeometry()->GetSpacing();
		MITK_INFO << image_spacing;
		MITK_INFO << target_spacing;
		mitk::Image::Pointer res = mitk::Image::New();
		ImageType::Pointer conv;
		double x_mul = image_spacing[0] / target_spacing[0];
		double y_mul = image_spacing[1] / target_spacing[1];
		double z_mul = image_spacing[2] / target_spacing[2];
		MITK_INFO << x_mul;
		MITK_INFO << y_mul;
		MITK_INFO << z_mul;
		bool upsample = false;
		if ((abs(round(x_mul) -x_mul) >= 0.000001) || (abs(round(y_mul) - y_mul) >= 0.000001) || (abs(round(z_mul) - z_mul) >= 0.000001))
		{
			MITK_INFO << "Different Spacing - Loaded Datas are weired";
			return;
		}
		else if(x_mul == 1.0 && y_mul == 1.0 && z_mul == 1.0)
		{
			upsample = false;
		}
		else
		{
			upsample = true;
		}
			

		if (upsample)
		{
			MITK_INFO << "We need upsampling x3";
			int dimx = image->GetDimension(0);
			int dimy = image->GetDimension(1);
			int dimz = image->GetDimension(2);

			int min = -1;
			int min_dim = 0;
			if (min > dimx) {
				min = dimx;
				min_dim = 0;
			}
			if (min > dimy) {
				min = dimy;
				min_dim = 1;
			}
			if (min > dimz) {
				min = dimz;
				min_dim = 2;
			}
			vtkSmartPointer<vtkImageResample> resample = vtkSmartPointer<vtkImageResample>::New();
			resample->SetInputData(image->GetVtkImageData());

			mitk::Vector3D dd = image->GetGeometry()->GetSpacing();

			double factorX = round(z_mul);// (double)m_Controls.factorX->value();
			double factorY = round(y_mul);// (double)m_Controls.factorY->value();
			double factorZ = round(x_mul);// (double)m_Controls.factorZ->value();

			resample->SetAxisMagnificationFactor(0, factorZ);
			resample->SetAxisMagnificationFactor(1, factorY);
			resample->SetAxisMagnificationFactor(2, factorX);
			dd[0] /= factorZ;
			dd[1] /= factorY;
			dd[2] /= factorX;


			/*switch (min_dim)
			{
			case 0:
				resample->SetAxisMagnificationFactor(2, factor);
				dd[2] /= factor;
				break;
			case 1:
				resample->SetAxisMagnificationFactor(1, factor);
				dd[1] /= factor;
				break;
			case 2:
				resample->SetAxisMagnificationFactor(0, factor);
				dd[0] /= factor;
				break;
			}*/
			resample->Update();

			res->Initialize(resample->GetOutput());
			res->SetVolume(resample->GetOutput()->GetScalarPointer());
			res->Update();
			res->GetGeometry()->SetIndexToWorldTransformByVtkMatrix(image->GetGeometry()->GetVtkMatrix());
			res->GetGeometry()->SetSpacing(dd);
			res->Update();
			mitk::CastToItkImage(res, conv);
			MITK_INFO << "Upsampling x3 Done";
		}
		else
		{
			MITK_INFO << "We don't need upsampling";
			mitk::CastToItkImage(image, conv);
		}
		ImageType::Pointer target;
		mitk::CastToItkImage(image_target, target);

		ImageType::Pointer cropped = ImageType::New();
		DeepCopy(target, cropped);
		mitk::Image::IndexType index;
		
		if(upsample)
			res->GetGeometry()->WorldToIndex(image_target->GetGeometry()->GetOrigin(), index);
		else
			image->GetGeometry()->WorldToIndex(image_target->GetGeometry()->GetOrigin(), index);
		MITK_INFO << index;
		//MITK_INFO << conv;
		ImageType::IndexType idx;
		itk::ImageRegion<3U> size = cropped->GetLargestPossibleRegion();
		for (int i = 0; i < size.GetSize(0); i++)
		{
			for (int j = 0; j < size.GetSize(1); j++)
			{
				for (int k = 0; k < size.GetSize(2); k++)
				{
					idx[0] = i + index[0];
					idx[1] = j + index[1];
					idx[2] = k + index[2];
					float val = conv->GetPixel(idx);
					idx[0] = i;
					idx[1] = j;
					idx[2] = k;
					cropped->SetPixel(idx, val);
				}
			}
		}
		MITK_INFO << "Cropped";

		mitk::Image::Pointer cropped_image;
		mitk::CastToMitkImage(cropped, cropped_image);
		cropped_image->SetGeometry(image_target->GetGeometry());
		mitk::DataNode::Pointer cropNode = mitk::DataNode::New();
		cropNode->SetData(cropped_image);
		std::string a = node_target->GetName();
		char last_char = a.back();
		MITK_INFO << last_char;
		if(last_char == 'A')
		{
			a.resize(a.size() - 4);
		}
		else if (last_char == 'a')
		{
			a.resize(a.size() - 8);
		}
		cropNode->SetName(a + "cropped");
		this->GetDataStorage()->Add(cropNode);
	}
}

void DeepCopy(ImageType::Pointer input, ImageType::Pointer output)
{
	output->SetRegions(input->GetLargestPossibleRegion());
	output->SetSpacing(input->GetSpacing());
	output->Allocate();
	output->FillBuffer(0);
}

//Fit image to masking label
void Exampleplugin::DoImageTest()
{
    QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
    if (nodes.empty())
        return;

	mitk::DataNode *node,*node_image,*node_pmma,*node_vert;
	for (int i = 0; i < 3; i++)
	{
		node = nodes.at(i);
		std::string a = node->GetName();
		char last_char = a.back();
		MITK_INFO << last_char;
		//cropped
		if (last_char == 'd')
		{
			node_image = nodes.at(i);
		}
		//Vertebra
		else if (last_char == 'a')
		{
			node_vert = nodes.at(i);
		}
		//PMMA
		else if (last_char == 'A')
		{
			node_pmma = nodes.at(i);
		}
	}
	
    if (!node_image | !node_pmma | !node_vert)
    {
        // Nothing selected. Inform the user and return
        QMessageBox::information(NULL, "Template", "Please load and select an image before starting image processing.");
        return;
    }

    // here we have a valid mitk::DataNode

    // a node itself is not very useful, we need its data item (the image)
    mitk::BaseData *image_data = node_image->GetData();
    mitk::BaseData *pmma_data = node_pmma->GetData();
    mitk::BaseData *vert_data = node_vert->GetData();
    if (image_data && pmma_data && vert_data)
    {
		// test if this data item is an image or not (could also be a surface or something totally different)
		mitk::Image *image_mitk = dynamic_cast<mitk::Image *>(image_data);
		mitk::Image *pmma_mitk = dynamic_cast<mitk::Image *>(pmma_data);
		mitk::Image *vert_mitk = dynamic_cast<mitk::Image *>(vert_data);

		//itk::ExtractImageFilter<ImageType, ImageType>::Pointer cropper = itk::ExtractImageFilter<ImageType, ImageType>::New();
		itk::CropImageFilter<ImageType, ImageType>::Pointer cropper = itk::CropImageFilter<ImageType, ImageType>::New();

		ImageType::Pointer image;
		mitk::CastToItkImage(image_mitk, image);
		ImageType::Pointer pmma;
		mitk::CastToItkImage(pmma_mitk, pmma);
		ImageType::Pointer vert;
		mitk::CastToItkImage(vert_mitk, vert);

		itk::ImageRegion<3U> size = image->GetLargestPossibleRegion();
		MITK_INFO << size;
		ImageType::IndexType idx;
		float val1, val2;
		int minx = 10000, miny = 10000, minz = 10000;
		int maxx = -1, maxy = -1, maxz = -1;
		for (int i = 0; i < size.GetSize(0); i++)
		{
			for (int j = 0; j < size.GetSize(1); j++)
			{
				for (int k = 0; k < size.GetSize(2); k++)
				{
					idx[0] = i;
					idx[1] = j;
					idx[2] = k;					
					val1 = pmma->GetPixel(idx);
					val2 = vert->GetPixel(idx);
					if (val1!=0 || val2!=0)
					{
						if (minx > i)
						{
							minx = i;
						}
						if (miny > j)
						{
							miny = j;
						}
						if (minz > k)
						{
							minz = k;
						}
						if (maxx < i)
						{
							maxx = i;
						}
						if (maxy < j)
						{
							maxy = j;
						}
						if (maxz < k)
						{
							maxz = k;
						}
					}
				}
			}
		}
		MITK_INFO << minx << " " << maxx << " " << miny << " " << maxy << " " << minz << " " << maxz;
		minx = max(minx - 2, 0);
		miny = max(miny - 2, 0);
		minz = max(minz - 2, 0);
		maxx = max(int(size.GetSize(0)) - 1 - maxx - 2, 0);
		maxy = max(int(size.GetSize(1)) - 1 - maxy - 2, 0);
		maxz = max(int(size.GetSize(2)) - 1 - maxz - 2, 0);
		MITK_INFO << minx << " " << maxx << " " << miny << " " << maxy << " " << minz << " " << maxz;
		cropper->SetInput(image);
		ImageType::SizeType cropsize_lower;
		cropsize_lower[0] = minx;
		cropsize_lower[1] = miny;
		cropsize_lower[2] = minz;
		cropper->SetLowerBoundaryCropSize(cropsize_lower);
		ImageType::SizeType cropsize_upper;
		cropsize_upper[0] = maxx;
		cropsize_upper[1] = maxy;
		cropsize_upper[2] = maxz;
		cropper->SetUpperBoundaryCropSize(cropsize_upper);
		cropper->Update();
		image = cropper->GetOutput();

		itk::CropImageFilter<ImageType, ImageType>::Pointer cropper2 = itk::CropImageFilter<ImageType, ImageType>::New();
		cropper2->SetInput(pmma);
		cropper2->SetLowerBoundaryCropSize(cropsize_lower);
		cropper2->SetUpperBoundaryCropSize(cropsize_upper);
		cropper2->Update();
		pmma = cropper2->GetOutput();

		itk::CropImageFilter<ImageType, ImageType>::Pointer cropper3 = itk::CropImageFilter<ImageType, ImageType>::New();
		cropper3->SetInput(vert);
		cropper3->SetLowerBoundaryCropSize(cropsize_lower);
		cropper3->SetUpperBoundaryCropSize(cropsize_upper);
		cropper3->Update();
		vert = cropper3->GetOutput();

		mitk::Image::Pointer cropped_image;
		mitk::CastToMitkImage(image, cropped_image);
		//cropped_image->SetGeometry(image_mitk->GetGeometry());
		mitk::DataNode::Pointer cropNode = mitk::DataNode::New();
		cropNode->SetData(cropped_image);
		cropNode->SetName(node_image->GetName());
		this->GetDataStorage()->Add(cropNode);

		mitk::Image::Pointer cropped_image2;
		mitk::CastToMitkImage(pmma, cropped_image2);
		//cropped_image2->SetGeometry(image_mitk->GetGeometry());
		mitk::DataNode::Pointer cropNode2 = mitk::DataNode::New();
		cropNode2->SetData(cropped_image2);
		cropNode2->SetName(node_pmma->GetName());
		this->GetDataStorage()->Add(cropNode2);

		mitk::Image::Pointer cropped_image3;
		mitk::CastToMitkImage(vert, cropped_image3);
		//cropped_image3->SetGeometry(image_mitk->GetGeometry());
		mitk::DataNode::Pointer cropNode3 = mitk::DataNode::New();
		cropNode3->SetData(cropped_image3);
		cropNode3->SetName(node_vert->GetName());
		this->GetDataStorage()->Add(cropNode3);
    }

}

void Exampleplugin::DoLabeling()
{
	QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
	if (nodes.empty())
		return;

	mitk::DataNode *node = nodes.front();

	if (!node)
	{
		// Nothing selected. Inform the user and return
		QMessageBox::information(NULL, "Template", "Please load and select an image before starting image processing.");
		return;
	}

	// here we have a valid mitk::DataNode

	// a node itself is not very useful, we need its data item (the image)
	mitk::BaseData *data = node->GetData();
	if (data)
	{
		// test if this data item is an image or not (could also be a surface or something totally different)
		mitk::Image *image = dynamic_cast<mitk::Image *>(data);
		if (image)
		{
			std::stringstream message;
			std::string name;
			message << "Performing Labeling for image ";
			if (node->GetName(name))
			{
				// a property called "name" was found for this DataNode
				message << "'" << name << "'";
			}
			message << ".";
			MITK_INFO << message.str();

			// actually do something here...

			//Two-pass algorithm for labeling
			ImageType::Pointer itkimage = ImageType::New();
			mitk::CastToItkImage(image, itkimage);

			typedef itk::ImageDuplicator< ImageType > DuplicatorType;
			DuplicatorType::Pointer duplicator = DuplicatorType::New();
			duplicator->SetInputImage(itkimage);
			duplicator->Update();
			ImageType::Pointer label = duplicator->GetOutput();
			label->FillBuffer(0);

			//First pass
			ImageType::SizeType size = itkimage->GetRequestedRegion().GetSize();
			ImageType::IndexType pixelIndex;
			ImageType::IndexType Index;
			int labelNum = 0;
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{		
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						bool stop = false;
						if (itkimage->GetPixel(pixelIndex) != 0)
						{
							for (int i = -1; i <= 1; i++)
							{
								for (int j = -1; j <= 1; j++)
								{
									for (int k = -1; k <= 1; k++)
									{
										if (label->GetPixel(pixelIndex) != 0)
										{
											stop = true;
											break;
										}
										Index[0] = (x + i == -1 || x + i == size[0]) ? x : x + i;
										Index[1] = (y + j == -1 || y + j == size[1]) ? y : y + j;
										Index[2] = (z + k == -1 || z + k == size[2]) ? z : z + k;
										label->SetPixel(pixelIndex, label->GetPixel(Index));
									}
									if (stop)
										break;
								}
								if (stop)
									break;
							}
							if (label->GetPixel(pixelIndex) == 0)
							{
								labelNum++;
								label->SetPixel(pixelIndex, labelNum);
							}
						}
					}
				}
			}
			MITK_INFO << labelNum;
			int num = labelNum;

			//Second pass
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						if (label->GetPixel(pixelIndex) != 0)
						{
							for (int i = -1; i <= 1; i++)
							{
								for (int j = -1; j <= 1; j++)
								{
									for (int k = -1; k <= 1; k++)
									{
										Index[0] = (x + i == -1 || x + i == size[0]) ? x : x + i;
										Index[1] = (y + j == -1 || y + j == size[1]) ? y : y + j;
										Index[2] = (z + k == -1 || z + k == size[2]) ? z : z + k;
										if ((label->GetPixel(Index) != 0) && (label->GetPixel(Index) != label->GetPixel(pixelIndex)))
										{
											mergeLabel(label, label->GetPixel(Index), label->GetPixel(pixelIndex));
											num--;
											//MITK_INFO << "merged";
										}
									}
								}
							}
						}
						
					}
				}
			}
			MITK_INFO << num;
			
			//statics
			
			int* stat = new int[labelNum+1];
			//stat = { 0, };
			std::fill_n(stat, labelNum + 1, 0);
			
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						int tag = label->GetPixel(pixelIndex);

						stat[tag]++;
					}
				}
			}
			
			int thresholdLabel = 0;
			for (int i = 0; i < labelNum; i++)
			{
				if (stat[i] < thresholdLabel && stat[i] != 0)
				{
					stat[i] = 0;
					num--;
				}
				//�ϴ��� �����ִ¾ֵ� �� ���� -> ���� �����ϴ� ��� ����
				if (stat[i] > 500 && stat[i] != 0)
				{
					stat[i] = 0;
					num--;
				}
				
			}

			
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						int tag = label->GetPixel(pixelIndex);
						if (stat[tag] == 0)
							label->SetPixel(pixelIndex, 0);
					}
				}
			}
			MITK_INFO << num;

			sortLabel(label, labelNum);

			mitk::Image::Pointer sImage;
			mitk::CastToMitkImage(label, sImage);
			mitk::DataNode::Pointer sNode = node->Clone();
			sNode->SetData(sImage);
			sNode->SetName(name + "_label");
			this->GetDataStorage()->Add(sNode);
			
			MITK_INFO << "Labeling End";
		}
	}
}

void Exampleplugin::DoLabeling2()
{
	QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
	if (nodes.empty())
		return;

	mitk::DataNode *node = nodes.front();

	if (!node)
	{
		// Nothing selected. Inform the user and return
		QMessageBox::information(NULL, "Template", "Please load and select an image before starting image processing.");
		return;
	}

	// here we have a valid mitk::DataNode

	// a node itself is not very useful, we need its data item (the image)
	mitk::BaseData *data = node->GetData();
	
	if (data)
	{
		// test if this data item is an image or not (could also be a surface or something totally different)
		//MITK_INFO << nodes.size();
		mitk::Image *image1 = dynamic_cast<mitk::Image *>(data);
		nodes.pop_front();
		mitk::Image *image2 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image3 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		if (image1 && image2 && image3)
		{
			std::stringstream message;
			std::string name;
			message << "Performing Labeling for image ";
			if (node->GetName(name))
			{
				// a property called "name" was found for this DataNode
				message << "'" << name << "'";
			}
			message << ".";
			MITK_INFO << message.str();

			// actually do something here...
			ImageType::Pointer ux = ImageType::New();
			mitk::CastToItkImage(image1, ux);
			ImageType::Pointer uy = ImageType::New();
			mitk::CastToItkImage(image2, uy);
			ImageType::Pointer uz = ImageType::New();
			mitk::CastToItkImage(image3, uz);

			typedef itk::ImageDuplicator< ImageType > DuplicatorType;
			DuplicatorType::Pointer duplicator = DuplicatorType::New();
			duplicator->SetInputImage(ux);
			duplicator->Update();
			ImageType::Pointer FinalLabel = duplicator->GetOutput();

			typedef itk::StatisticsImageFilter<ImageType> StatisticsImageFilterType;
			StatisticsImageFilterType::Pointer statisticsImageFilter = StatisticsImageFilterType::New();
			statisticsImageFilter->SetInput(FinalLabel);
			statisticsImageFilter->Update();

			//uy
			ImageType::SizeType size = FinalLabel->GetRequestedRegion().GetSize();
			ImageType::IndexType pixelIndex;
			ImageType::IndexType Index;
			int labelNum = statisticsImageFilter->GetMaximum();
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						if (uy->GetPixel(pixelIndex) != 0 && FinalLabel->GetPixel(pixelIndex) == 0)
						{
							for (int i = -1; i <= 1; i++)
							{
								for (int j = -1; j <= 1; j++)
								{
									for (int k = -1; k <= 1; k++)
									{
										if (FinalLabel->GetPixel(pixelIndex) != 0)
											break;
										Index[0] = (x + i == -1 || x + i == size[0]) ? x : x + i;
										Index[1] = (y + j == -1 || y + j == size[1]) ? y : y + j;
										Index[2] = (z + k == -1 || z + k == size[2]) ? z : z + k;
										FinalLabel->SetPixel(pixelIndex, FinalLabel->GetPixel(Index));
									}
								}
							}
							if (FinalLabel->GetPixel(pixelIndex) == 0)
							{
								labelNum++;
								FinalLabel->SetPixel(pixelIndex, labelNum);
							}
						}
					}
				}
			}
			//Second pass
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						if (FinalLabel->GetPixel(pixelIndex) != 0)
						{
							for (int i = -1; i <= 1; i++)
							{
								for (int j = -1; j <= 1; j++)
								{
									for (int k = -1; k <= 1; k++)
									{
										Index[0] = (x + i == -1 || x + i == size[0]) ? x : x + i;
										Index[1] = (y + j == -1 || y + j == size[1]) ? y : y + j;
										Index[2] = (z + k == -1 || z + k == size[2]) ? z : z + k;
										if ((FinalLabel->GetPixel(Index) != 0) && (FinalLabel->GetPixel(Index) != FinalLabel->GetPixel(pixelIndex)))
										{
											mergeLabel(FinalLabel, FinalLabel->GetPixel(Index), FinalLabel->GetPixel(pixelIndex));
											//MITK_INFO << "merged";
										}
									}
								}
							}
						}

					}
				}
			}
			//uz
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						if (uz->GetPixel(pixelIndex) != 0 && FinalLabel->GetPixel(pixelIndex) == 0)
						{
							for (int i = -1; i <= 1; i++)
							{
								for (int j = -1; j <= 1; j++)
								{
									for (int k = -1; k <= 1; k++)
									{
										if (FinalLabel->GetPixel(pixelIndex) != 0)
											break;
										Index[0] = (x + i == -1 || x + i == size[0]) ? x : x + i;
										Index[1] = (y + j == -1 || y + j == size[1]) ? y : y + j;
										Index[2] = (z + k == -1 || z + k == size[2]) ? z : z + k;
										FinalLabel->SetPixel(pixelIndex, FinalLabel->GetPixel(Index));
									}
								}
							}
							if (FinalLabel->GetPixel(pixelIndex) == 0)
							{
								labelNum++;
								FinalLabel->SetPixel(pixelIndex, labelNum);
							}
						}
					}
				}
			}
			//Second pass
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						if (FinalLabel->GetPixel(pixelIndex) != 0)
						{
							for (int i = -1; i <= 1; i++)
							{
								for (int j = -1; j <= 1; j++)
								{
									for (int k = -1; k <= 1; k++)
									{
										Index[0] = (x + i == -1 || x + i == size[0]) ? x : x + i;
										Index[1] = (y + j == -1 || y + j == size[1]) ? y : y + j;
										Index[2] = (z + k == -1 || z + k == size[2]) ? z : z + k;
										if ((FinalLabel->GetPixel(Index) != 0) && (FinalLabel->GetPixel(Index) != FinalLabel->GetPixel(pixelIndex)))
										{
											mergeLabel(FinalLabel, FinalLabel->GetPixel(Index), FinalLabel->GetPixel(pixelIndex));
											//MITK_INFO << "merged";
										}
									}
								}
							}
						}

					}
				}
			}

			sortLabel(FinalLabel, labelNum);

			StatisticsImageFilterType::Pointer statisticsImageFilter2 = StatisticsImageFilterType::New();
			statisticsImageFilter2->SetInput(FinalLabel);
			statisticsImageFilter2->Update();

			MITK_INFO << statisticsImageFilter2->GetMaximum();

			//save
			mitk::Image::Pointer sImage;
			mitk::CastToMitkImage(FinalLabel, sImage);
			mitk::DataNode::Pointer sNode = node->Clone();
			sNode->SetData(sImage);
			sNode->SetName(name + "_final");
			this->GetDataStorage()->Add(sNode);

			MITK_INFO << "Final Labeling End";


		}
	}
}

void Exampleplugin::DoTracking()
{
	QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
	if (nodes.empty())
		return;

	mitk::DataNode *node = nodes.front();

	if (!node)
	{
		// Nothing selected. Inform the user and return
		QMessageBox::information(NULL, "Template", "Please load and select an image before starting image processing.");
		return;
	}

	// here we have a valid mitk::DataNode

	// a node itself is not very useful, we need its data item (the image)
	mitk::BaseData *data = node->GetData();

	if (data)
	{
		// test if this data item is an image or not (could also be a surface or something totally different)
		//MITK_INFO << nodes.size();
		mitk::Image *image1 = dynamic_cast<mitk::Image *>(data);
		nodes.pop_front();
		mitk::Image *image2 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image3 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image4 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image5 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		if (image1 && image2 && image3 && image4 && image5)
		{
			std::stringstream message;
			std::string name;
			message << "Performing Tracking for image ";
			if (node->GetName(name))
			{
				// a property called "name" was found for this DataNode
				message << "'" << name << "'";
			}
			message << ".";
			MITK_INFO << message.str();

			// actually do something here...
			ImageType::Pointer init0 = ImageType::New();
			mitk::CastToItkImage(image1, init0);

			ImageType::Pointer frame01 = ImageType::New();
			mitk::CastToItkImage(image2, frame01);

			ImageType::Pointer ux01 = ImageType::New();
			mitk::CastToItkImage(image3, ux01);
			ImageType::Pointer uy01 = ImageType::New();
			mitk::CastToItkImage(image4, uy01);
			ImageType::Pointer uz01 = ImageType::New();
			mitk::CastToItkImage(image5, uz01);			

			MITK_INFO << "Start init0";
			//init0
			typedef itk::StatisticsImageFilter<ImageType> StatisticsImageFilterType;
			StatisticsImageFilterType::Pointer statisticsImageFilter1 = StatisticsImageFilterType::New();
			statisticsImageFilter1->SetInput(init0);
			statisticsImageFilter1->Update();
			labelnum0 = statisticsImageFilter1->GetMaximum() + 1;
			int * stat_0 = new int[labelnum0];
			std::fill_n(stat_0, labelnum0, 0);
			position_0 = new int*[labelnum0];
			for (int i = 0; i < labelnum0; i++)
			{
				position_0[i] = new int[3];
				std::fill_n(position_0[i], 3, 0);
			}
			//vel init
			vel = new float *[labelnum0];
			for (int i = 0; i < labelnum0; i++)
			{
				vel[i] = new float[3];
				std::fill_n(vel[i], 3, 0);
			}

			ImageType::SizeType size = init0->GetRequestedRegion().GetSize();
			ImageType::IndexType pixelIndex;
			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						int tag = init0->GetPixel(pixelIndex);

						stat_0[tag]++;
						position_0[tag][0] += x;
						position_0[tag][1] += y;
						position_0[tag][2] += z;
					}
				}
			}

			for (int i = 0; i < labelnum0; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					if(stat_0[i] != 0)
						position_0[i][j] /= float(stat_0[i]);	
				}
			}

			MITK_INFO << "Start frame01";
			//frame01
			StatisticsImageFilterType::Pointer statisticsImageFilter2 = StatisticsImageFilterType::New();
			statisticsImageFilter2->SetInput(frame01);
			statisticsImageFilter2->Update();
			int labelnum01 = statisticsImageFilter2->GetMaximum() + 1;
			int * stat_01 = new int[labelnum01];
			std::fill_n(stat_01, labelnum01, 0);
			int ** position_01 = new int*[labelnum01];
			for (int i = 0; i < labelnum01; i++)
			{
				position_01[i] = new int[3];
				std::fill_n(position_01[i], 3, 0);
			}

			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						int tag = frame01->GetPixel(pixelIndex);

						stat_01[tag]++;
						position_01[tag][0] += x;
						position_01[tag][1] += y;
						position_01[tag][2] += z;
					}
				}
			}

			for (int i = 0; i < labelnum01; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					if (stat_01[i] != 0)
						position_01[i][j] /= float(stat_01[i]);
				}
			}
			
			// LDs
			typedef itk::ImageDuplicator< ImageType > DuplicatorType;
			DuplicatorType::Pointer duplicator = DuplicatorType::New();
			duplicator->SetInputImage(init0);
			duplicator->Update();

			LD = duplicator->GetOutput();
			LD->FillBuffer(0);
			for (int i = 1; i < labelnum0; i++)
			{
				pixelIndex[0] = position_0[i][0];
				pixelIndex[1] = position_0[i][1];
				pixelIndex[2] = position_0[i][2];
				LD->SetPixel(pixelIndex, i);

			}
			/*
			////////////////////////////////////////////////////////////
			//initial position data
			DuplicatorType::Pointer duplicator1 = DuplicatorType::New();
			duplicator1->SetInputImage(LD);
			duplicator1->Update();

			ImageType::Pointer LD1 = duplicator->GetOutput();


			for (int i = 1; i < labelnum0; i++)
			{
				for (int x = -1; x <= 1; x++)
				{
					for (int y = -1; y <= 1; y++)
					{
						for (int z = -1; z <= 1; z++)
						{
							pixelIndex[0] = (x + position_0[i][0] == -1 || x + position_0[i][0] == size[0]) ? position_0[i][0] : x + position_0[i][0];
							pixelIndex[1] = (y + position_0[i][1] == -1 || y + position_0[i][1] == size[1]) ? position_0[i][1] : y + position_0[i][1];
							pixelIndex[2] = (z + position_0[i][2] == -1 || z + position_0[i][2] == size[2]) ? position_0[i][2] : z + position_0[i][2];
							LD1->SetPixel(pixelIndex, 1);
						}
					}
				}
			}
			//save
			mitk::Image::Pointer sImage1;
			mitk::CastToMitkImage(LD1, sImage1);
			mitk::DataNode::Pointer sNode1 = node->Clone();
			sNode1->SetData(sImage1);
			sNode1->SetName("LD_init");
			this->GetDataStorage()->Add(sNode1);
			*/
			/////////////////////////////////////////////////////////
			MITK_INFO << "Start cal";
			//cal
			//for glyph
			vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
			vtkSmartPointer<vtkFloatArray> vectors = vtkSmartPointer<vtkFloatArray>::New();
			vectors->SetName("vectors");
			vectors->SetNumberOfComponents(3);
			vtkSmartPointer<vtkFloatArray> scales = vtkSmartPointer<vtkFloatArray>::New();
			scales->SetName("scales");
			scales->SetNumberOfComponents(1);

			for (int i = 1; i < labelnum0; i++)
			{
				int min = 0;
				float distance = 10000000000.0;
				for (int j = 0; j < labelnum01; j++)
				{
					if (distance > sqrt(pow(position_0[i][0] - position_01[j][0], 2) + pow(position_0[i][1] - position_01[j][1], 2) + pow(position_0[i][2] - position_01[j][2], 2)))
					{
						min = j;
						distance = sqrt(pow(position_0[i][0] - position_01[j][0], 2) + pow(position_0[i][1] - position_01[j][1], 2) + pow(position_0[i][2] - position_01[j][2], 2));
					}
				}
				//distance of labeled OPFL and LD position
				if (distance < 3 && min != 0)
				{
					pixelIndex[0] = position_01[min][0];
					pixelIndex[1] = position_01[min][1];
					pixelIndex[2] = position_01[min][2];
					// velocity = 1/ratio pixel 
					static float ratio = 5;
					vel[i][0] += ux01->GetPixel(pixelIndex) * ratio;
					vel[i][1] += uy01->GetPixel(pixelIndex) * ratio;
					vel[i][2] += uz01->GetPixel(pixelIndex) * ratio;

					int vel_x = vel[i][0] > 0 ? int(vel[i][0] + 0.5) : int(vel[i][0] - 0.5);
					int vel_y = vel[i][1] > 0 ? int(vel[i][1] + 0.5) : int(vel[i][1] - 0.5);
					int vel_z = vel[i][2] > 0 ? int(vel[i][2] + 0.5) : int(vel[i][2] - 0.5);
					MITK_INFO << "Label " << i << " vel x: " << vel_x << ", vel y: " << vel_y << ", vel z: " << vel_z << ", min: " << min;
					// apply movement
					pixelIndex[0] = position_0[i][0];
					pixelIndex[1] = position_0[i][1];
					pixelIndex[2] = position_0[i][2];

					LD->SetPixel(pixelIndex, 0);

					//for glyph
					if (!(vel_x == 0 && vel_y == 0 && vel_z == 0))
					{
						points->InsertNextPoint(pixelIndex[0], pixelIndex[1], pixelIndex[2]);
						float vec[3] = {vel_x, vel_y, vel_z };
						vectors->InsertNextTupleValue(vec);
						float scale[1] = { sqrt(vel_x*vel_x + vel_y*vel_y + vel_z*vel_z) };
						MITK_INFO << "Scale : " << scale[0];
						scales->InsertNextTupleValue(scale);
					}
					position_0[i][0] += vel_x;
					position_0[i][1] += vel_y;
					position_0[i][2] += vel_z;

					pixelIndex[0] = position_0[i][0];
					pixelIndex[1] = position_0[i][1];
					pixelIndex[2] = position_0[i][2];

					LD->SetPixel(pixelIndex, i);

				}
			}
			
			
			// For visualization : make 3x3x3 cube
			/*
			for (int i = 1; i < labelnum0; i++)
			{
				for (int x = -1; x <= 1; x++)
				{
					for (int y = -1; y <= 1; y++)
					{
						for (int z = -1; z <= 1; z++)
						{
							pixelIndex[0] = (x + position_0[i][0] == -1 || x + position_0[i][0] == size[0]) ? position_0[i][0] : x + position_0[i][0];
							pixelIndex[1] = (y + position_0[i][1] == -1 || y + position_0[i][1] == size[1]) ? position_0[i][1] : y + position_0[i][1];
							pixelIndex[2] = (z + position_0[i][2] == -1 || z + position_0[i][2] == size[2]) ? position_0[i][2] : z + position_0[i][2];
							LD->SetPixel(pixelIndex, 1);
						}
					}
				}
			}
			

			//save
			mitk::Image::Pointer sImage;
			mitk::CastToMitkImage(LD, sImage);
			mitk::DataNode::Pointer sNode = node->Clone();
			sNode->SetData(sImage);
			sNode->SetName("LD_pos");
			this->GetDataStorage()->Add(sNode);
			MITK_INFO << "end";
			*/
			//mitk::Image::Pointer sImage;
			//mitk::CastToMitkImage(LD, sImage);

			// Combine into a polydata
			vtkSmartPointer<vtkPolyData> polydata =
				vtkSmartPointer<vtkPolyData>::New();
			polydata->SetPoints(points);
			polydata->GetPointData()->SetVectors(vectors);
			polydata->GetPointData()->SetScalars(scales);

			vtkSmartPointer<vtkPolyData> glyph =
				vtkSmartPointer<vtkPolyData>::New();
			// Create anything you want here, we will use a cube for the demo.
			vtkSmartPointer<vtkArrowSource> cubeSource =
				vtkSmartPointer<vtkArrowSource>::New();

			vtkSmartPointer<vtkGlyph3D> glyph3D =
				vtkSmartPointer<vtkGlyph3D>::New();


			glyph3D->SetVectorModeToUseVector();
			glyph3D->SetScaleModeToScaleByScalar();
			glyph3D->SetSourceConnection(cubeSource->GetOutputPort());
			glyph3D->SetInputData(polydata);
			glyph3D->ScalingOn();
			glyph3D->Update();

			mitk::Surface::Pointer sSurface = mitk::Surface::New();
			sSurface->SetVtkPolyData(glyph3D->GetOutput());
			sSurface->SetGeometry(image1->GetGeometry());

			mitk::DataNode::Pointer surNode = mitk::DataNode::New();
			surNode->SetData(sSurface);
			surNode->SetName("glyph");
			//float r[3] = { 255, 0, 0 };
			//surNode->SetColor(r);
			this->GetDataStorage()->Add(surNode);

			/*
			// Visualize
			vtkSmartPointer<vtkPolyDataMapper> mapper =
				vtkSmartPointer<vtkPolyDataMapper>::New();
			mapper->SetInputConnection(glyph3D->GetOutputPort());

			vtkSmartPointer<vtkActor> actor =
				vtkSmartPointer<vtkActor>::New();
			actor->SetMapper(mapper);

			vtkSmartPointer<vtkRenderer> renderer =
				vtkSmartPointer<vtkRenderer>::New();
			vtkSmartPointer<vtkRenderWindow> renderWindow =
				vtkSmartPointer<vtkRenderWindow>::New();
			renderWindow->AddRenderer(renderer);
			vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
				vtkSmartPointer<vtkRenderWindowInteractor>::New();
			renderWindowInteractor->SetRenderWindow(renderWindow);

			renderer->AddActor(actor);
			renderer->SetBackground(.3, .6, .3); // Background color green

			renderWindow->Render();
			renderWindowInteractor->Start();
			*/
		}
	}
}


void Exampleplugin::DoTracking2()
{
	QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
	if (nodes.empty())
		return;

	mitk::DataNode *node = nodes.front();

	if (!node)
	{
		// Nothing selected. Inform the user and return
		QMessageBox::information(NULL, "Template", "Please load and select an image before starting image processing.");
		return;
	}

	// here we have a valid mitk::DataNode

	// a node itself is not very useful, we need its data item (the image)
	mitk::BaseData *data = node->GetData();

	if (data)
	{
		// test if this data item is an image or not (could also be a surface or something totally different)
		//MITK_INFO << nodes.size();
		mitk::Image *image2 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image3 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image4 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		mitk::Image *image5 = dynamic_cast<mitk::Image *>(nodes.front()->GetData());
		nodes.pop_front();
		if (image2 && image3 && image4 && image5)
		{
			std::stringstream message;
			std::string name;
			message << "Performing Tracking for image ";
			if (node->GetName(name))
			{
				// a property called "name" was found for this DataNode
				message << "'" << name << "'";
			}
			message << ".";
			MITK_INFO << message.str();

			ImageType::Pointer frame01 = ImageType::New();
			mitk::CastToItkImage(image2, frame01);

			ImageType::Pointer ux01 = ImageType::New();
			mitk::CastToItkImage(image3, ux01);
			ImageType::Pointer uy01 = ImageType::New();
			mitk::CastToItkImage(image4, uy01);
			ImageType::Pointer uz01 = ImageType::New();
			mitk::CastToItkImage(image5, uz01);

			typedef itk::StatisticsImageFilter<ImageType> StatisticsImageFilterType;
			ImageType::SizeType size = frame01->GetRequestedRegion().GetSize();
			ImageType::IndexType pixelIndex;

			MITK_INFO << "Start frame01";
			//frame01
			StatisticsImageFilterType::Pointer statisticsImageFilter2 = StatisticsImageFilterType::New();
			statisticsImageFilter2->SetInput(frame01);
			statisticsImageFilter2->Update();
			int labelnum01 = statisticsImageFilter2->GetMaximum() + 1;
			int * stat_01 = new int[labelnum01];
			std::fill_n(stat_01, labelnum01, 0);
			int ** position_01 = new int*[labelnum01];
			for (int i = 0; i < labelnum01; i++)
			{
				position_01[i] = new int[3];
				std::fill_n(position_01[i], 3, 0);
			}

			for (unsigned int x = 0; x < size[0]; x++)
			{
				for (unsigned int y = 0; y < size[1]; y++)
				{
					for (unsigned int z = 0; z < size[2]; z++)
					{
						pixelIndex[0] = x;
						pixelIndex[1] = y;
						pixelIndex[2] = z;
						int tag = frame01->GetPixel(pixelIndex);

						stat_01[tag]++;
						position_01[tag][0] += x;
						position_01[tag][1] += y;
						position_01[tag][2] += z;
					}
				}
			}

			for (int i = 0; i < labelnum01; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					if (stat_01[i] != 0)
						position_01[i][j] /= float(stat_01[i]);
				}
			}
			
			/////////////////////////////////////////////////////////
			MITK_INFO << "Start cal";
			//cal
			//for glyph
			vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
			vtkSmartPointer<vtkFloatArray> vectors = vtkSmartPointer<vtkFloatArray>::New();
			vectors->SetName("vectors");
			vectors->SetNumberOfComponents(3);
			vtkSmartPointer<vtkFloatArray> scales = vtkSmartPointer<vtkFloatArray>::New();
			scales->SetName("scales");
			scales->SetNumberOfComponents(1);

			for (int i = 1; i < labelnum0; i++)
			{
				int min = 0;
				float distance = 10000000000.0;
				for (int j = 0; j < labelnum01; j++)
				{
					if (distance > sqrt(pow(position_0[i][0] - position_01[j][0], 2) + pow(position_0[i][1] - position_01[j][1], 2) + pow(position_0[i][2] - position_01[j][2], 2)))
					{
						min = j;
						distance = sqrt(pow(position_0[i][0] - position_01[j][0], 2) + pow(position_0[i][1] - position_01[j][1], 2) + pow(position_0[i][2] - position_01[j][2], 2));
					}
				}
				//distance of labeled OPFL and LD position
				if (distance < 3 && min != 0)
				{
					pixelIndex[0] = position_01[min][0];
					pixelIndex[1] = position_01[min][1];
					pixelIndex[2] = position_01[min][2];
					// vel = 1/ratio pixel 
					static float ratio = 5;
					vel[i][0] += ux01->GetPixel(pixelIndex) * ratio;
					vel[i][1] += uy01->GetPixel(pixelIndex) * ratio;
					vel[i][2] += uz01->GetPixel(pixelIndex) * ratio;

					int vel_x = vel[i][0] > 0 ? int(vel[i][0] + 0.5) : int(vel[i][0] - 0.5);
					int vel_y = vel[i][1] > 0 ? int(vel[i][1] + 0.5) : int(vel[i][1] - 0.5);
					int vel_z = vel[i][2] > 0 ? int(vel[i][2] + 0.5) : int(vel[i][2] - 0.5);
					MITK_INFO << "Label " << i << " vel x: " << vel_x << ", vel y: " << vel_y << ", vel z: " << vel_z << ", min: " << min;
					// apply movement
					pixelIndex[0] = position_0[i][0];
					pixelIndex[1] = position_0[i][1];
					pixelIndex[2] = position_0[i][2];

					LD->SetPixel(pixelIndex, 0);
					//for glyph
					if (!(vel_x == 0 && vel_y == 0 && vel_z == 0))
					{
						points->InsertNextPoint(pixelIndex[0], pixelIndex[1], pixelIndex[2]);
						float vec[3] = { vel_x, vel_y, vel_z };
						vectors->InsertNextTupleValue(vec);
						float scale[1] = { sqrt(vel_x*vel_x + vel_y*vel_y + vel_z*vel_z) };
						MITK_INFO << "Scale : " << scale[0];
						scales->InsertNextTupleValue(scale);
					}
					position_0[i][0] += vel_x;
					position_0[i][1] += vel_y;
					position_0[i][2] += vel_z;

					pixelIndex[0] = position_0[i][0];
					pixelIndex[1] = position_0[i][1];
					pixelIndex[2] = position_0[i][2];

					LD->SetPixel(pixelIndex, i);
				}
			}


			// Combine into a polydata
			vtkSmartPointer<vtkPolyData> polydata =
				vtkSmartPointer<vtkPolyData>::New();
			polydata->SetPoints(points);
			polydata->GetPointData()->SetVectors(vectors);
			polydata->GetPointData()->SetScalars(scales);

			vtkSmartPointer<vtkPolyData> glyph =
				vtkSmartPointer<vtkPolyData>::New();
			// Create anything you want here, we will use a cube for the demo.
			vtkSmartPointer<vtkArrowSource> cubeSource =
				vtkSmartPointer<vtkArrowSource>::New();

			vtkSmartPointer<vtkGlyph3D> glyph3D =
				vtkSmartPointer<vtkGlyph3D>::New();


			glyph3D->SetVectorModeToUseVector();
			glyph3D->SetScaleModeToScaleByScalar();
			glyph3D->SetColorModeToColorByScale();
			glyph3D->SetSourceConnection(cubeSource->GetOutputPort());
			glyph3D->SetInputData(polydata);
			glyph3D->ScalingOn();
			glyph3D->Update();

			mitk::Surface::Pointer sSurface = mitk::Surface::New();
			sSurface->SetVtkPolyData(glyph3D->GetOutput());
			sSurface->SetGeometry(image2->GetGeometry());

			mitk::DataNode::Pointer surNode = mitk::DataNode::New();
			surNode->SetData(sSurface);
			surNode->SetName("glyph");
			//float r[3] = { 0, 255, 0 };
			//surNode->SetColor(r);
			this->GetDataStorage()->Add(surNode);


		}
	}
}


void sortLabel(ImageType::Pointer label, int labelNum)
{
	//Labelnum stablizing
	int* stat = new int[labelNum + 1];
	int* changeRule = new int[labelNum + 1];
	std::fill_n(stat, labelNum + 1, 0);

	for (int i = 0; i < labelNum + 1; i++)
	{
		changeRule[i] = i;
	}
	ImageType::SizeType size = label->GetRequestedRegion().GetSize();
	ImageType::IndexType pixelIndex;
	for (unsigned int x = 0; x < size[0]; x++)
	{
		for (unsigned int y = 0; y < size[1]; y++)
		{
			for (unsigned int z = 0; z < size[2]; z++)
			{
				pixelIndex[0] = x;
				pixelIndex[1] = y;
				pixelIndex[2] = z;
				int tag = label->GetPixel(pixelIndex);

				stat[tag]++;
			}
		}
	}

	for (int i = 0; i < labelNum + 1; i++)
	{
		if (stat[i] == 0)
		{
			//find candidate
			int j = labelNum;
			while (j > i)
			{
				if (stat[j] != 0)
				{
					stat[j] = 0;

					//swapRule change
					changeRule[j] = i;
					break;
				}
				j--;
			}
			if (j == i)
				break;

		}
	}
	for (unsigned int x = 0; x < size[0]; x++)
	{
		for (unsigned int y = 0; y < size[1]; y++)
		{
			for (unsigned int z = 0; z < size[2]; z++)
			{
				pixelIndex[0] = x;
				pixelIndex[1] = y;
				pixelIndex[2] = z;
				int prev = label->GetPixel(pixelIndex);
				label->SetPixel(pixelIndex, changeRule[prev]);
			}
		}
	}
}

void mergeLabel(ImageType::Pointer label, float from, float to)
{
	ImageType::SizeType size = label->GetRequestedRegion().GetSize();

	for (unsigned int x = 0; x < size[0]; x++)
	{
		for (unsigned int y = 0; y < size[1]; y++)
		{
			for (unsigned int z = 0; z < size[2]; z++)
			{
				ImageType::IndexType pixelIndex;
				pixelIndex[0] = x;
				pixelIndex[1] = y;
				pixelIndex[2] = z;

				if (label->GetPixel(pixelIndex) == from)
					label->SetPixel(pixelIndex, to);
			}
		}
	}
}

void Exampleplugin::DoTest()
{
	vtkSmartPointer<vtkPoints> points =
		vtkSmartPointer<vtkPoints>::New();
	points->InsertNextPoint(0, 0, 0);
	points->InsertNextPoint(1, 1, 1);
	points->InsertNextPoint(2, 2, 2);

	// Setup scales.This can also be an Int array
		// char is used since it takes the least memory
	vtkSmartPointer<vtkUnsignedCharArray> colors =	vtkSmartPointer<vtkUnsignedCharArray>::New();
	colors->SetName("colors");
	colors->SetNumberOfComponents(3);
	unsigned char r[3] = { 255,0,0 };
	unsigned char g[3] = { 0,255,0 };
	unsigned char b[3] = { 0,0,255 };
	colors->InsertNextTupleValue(r);
	colors->InsertNextTupleValue(g);
	colors->InsertNextTupleValue(b);

	vtkSmartPointer<vtkIntArray> vectors = vtkSmartPointer<vtkIntArray>::New();
	vectors->SetName("vectors");
	vectors->SetNumberOfComponents(3);
	int x[3] = { 2,0,0 };
	int y[3] = { 0,1,0 };
	int z[3] = { -1,-1,-1};
	vectors->InsertNextTupleValue(x);
	vectors->InsertNextTupleValue(y);
	vectors->InsertNextTupleValue(z);

	vtkSmartPointer<vtkFloatArray> scales = vtkSmartPointer<vtkFloatArray>::New();
	scales->SetNumberOfComponents(3);
	float xs[1] = { 3.0 };
	float ys[1] = { 2.0 };
	float zs[1] = { 1.0 };
	scales->InsertNextTupleValue(xs);
	scales->InsertNextTupleValue(ys);
	scales->InsertNextTupleValue(zs);

	// Combine into a polydata
	vtkSmartPointer<vtkPolyData> polydata =
		vtkSmartPointer<vtkPolyData>::New();
	polydata->SetPoints(points);
	polydata->GetPointData()->SetVectors(vectors);
	polydata->GetPointData()->SetScalars(scales);

	// Create anything you want here, we will use a cube for the demo.
	vtkSmartPointer<vtkArrowSource> cubeSource =
		vtkSmartPointer<vtkArrowSource>::New();

	vtkSmartPointer<vtkGlyph3D> glyph3D =
		vtkSmartPointer<vtkGlyph3D>::New();


	glyph3D->SetVectorModeToUseVector();
	glyph3D->SetScaleModeToScaleByVector();
	glyph3D->SetColorModeToColorByScalar();
	glyph3D->SetSourceConnection(cubeSource->GetOutputPort());
	glyph3D->SetInputData(polydata);
	glyph3D->ScalingOn();
	glyph3D->Update();


	// Visualize
	vtkSmartPointer<vtkPolyDataMapper> mapper =
		vtkSmartPointer<vtkPolyDataMapper>::New();
	mapper->SetInputConnection(glyph3D->GetOutputPort());

	vtkSmartPointer<vtkActor> actor =
		vtkSmartPointer<vtkActor>::New();
	actor->SetMapper(mapper);

	vtkSmartPointer<vtkRenderer> renderer =
		vtkSmartPointer<vtkRenderer>::New();
	vtkSmartPointer<vtkRenderWindow> renderWindow =
		vtkSmartPointer<vtkRenderWindow>::New();
	renderWindow->AddRenderer(renderer);
	vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
		vtkSmartPointer<vtkRenderWindowInteractor>::New();
	renderWindowInteractor->SetRenderWindow(renderWindow);

	renderer->AddActor(actor);
	renderer->SetBackground(.3, .6, .3); // Background color green

	renderWindow->Render();
	renderWindowInteractor->Start();
}



void Exampleplugin::movechangeSpin()
{
	movement = m_Controls.moveSpin->value();
	m_Controls.moveSlider->setValue(movement);
	MITK_INFO << "movement value : " << movement;
}

void Exampleplugin::movechangeSlider()
{
	movement = m_Controls.moveSlider->value();
	m_Controls.moveSpin->setValue(movement);
	MITK_INFO << "movement value : " << movement;
}